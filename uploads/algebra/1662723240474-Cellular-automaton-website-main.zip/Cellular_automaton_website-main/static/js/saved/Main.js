// start całości projektu, utworzenie obiektów poszczególnych klas

//console.log("wczytano plik Main.js")

var net;
var boxes;

$(document).ready(function () {
    net = new Net()
    boxes = new Boxes()
})