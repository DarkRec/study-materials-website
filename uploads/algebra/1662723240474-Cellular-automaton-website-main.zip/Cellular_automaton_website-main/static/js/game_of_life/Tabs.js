//console.log("wczytano plik Tabs.js")
class Tabs {

    constructor() {
        //console.log("konstruktor klasy Tabs")

        this.tab = []
        this.new_tab = []
        this.suma_tab = []
        this.zero = []
    }
}